package com.boyyaharena.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedSlot = 12
    private var booked = mutableSetOf(3, 7, 12, 26, 31, 38, 44)
    private var pageTitle = "BOYYAH ARENA"

    private val bg = Color.rgb(6, 7, 11)
    private val card = Color.rgb(20, 22, 30)
    private val gold = Color.rgb(250, 204, 21)
    private val green = Color.rgb(34, 197, 94)
    private val red = Color.rgb(239, 68, 68)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 175, 188)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float = 15f, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }

    private fun button(text: String, action: () -> Unit, filled: Boolean = true): Button =
        Button(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(if (filled) Color.BLACK else white)
            if (filled) setBackgroundColor(gold) else setBackgroundColor(card)
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun cardView(title: String, body: String, actionText: String? = null, action: (() -> Unit)? = null): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(card)
        }
        box.addView(tv(title, 18f, white, true))
        box.addView(tv(body, 13f, muted))
        if (actionText != null && action != null) {
            box.addView(button(actionText, action), LinearLayout.LayoutParams(-1, dp(48)).apply {
                topMargin = dp(8)
            })
        }
        return box
    }

    private fun base(title: String, subtitle: String? = null, back: Boolean = false) {
        pageTitle = title
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(6))
        }

        if (back) {
            header.addView(button("‹", { showHome() }, false), LinearLayout.LayoutParams(dp(50), dp(48)))
        }
        val h = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        h.addView(tv(title, 22f, white, true))
        subtitle?.let { h.addView(tv(it, 12f, muted)) }
        header.addView(h, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(tv("👑", 24f))
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        if (!back) root.addView(bottomNav())
        setContentView(root)
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply {
            setBackgroundColor(Color.rgb(12, 14, 20))
            gravity = Gravity.CENTER
            setPadding(4, 5, 4, 5)
        }
        listOf(
            "⌂\nHome" to { showHome() },
            "🏆\nTournaments" to { showTournaments() },
            "🎟\nMy Slots" to { showMySlots() },
            "👤\nProfile" to { showProfile() }
        ).forEach { (label, action) ->
            val b = button(label, action, false).apply {
                textSize = 11f
                setPadding(0, 0, 0, 0)
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(58), 1f))
        }
        return nav
    }

    private fun showHome() {
        base("BOYYAH ARENA", "Play • Compete • Win")
        content.addView(cardView("🔥 SOLO BATTLE #001",
            "LIVE SOON  •  50 Slots  •  Entry Rs.100\n12 Sep 2026 • 8:00 PM PKT\nPrize Pool: Rs.5,000",
            "REGISTER NOW") { showTournamentDetails() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        content.addView(tv("Quick Access", 18f, white, true))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("🏆\nTournaments" to { showTournaments() },
            "🎟\nMy Slots" to { showMySlots() },
            "📺\nLive" to { showLive() },
            "📊\nRanking" to { showLeaderboard() }).forEach { (t,a) ->
            quick.addView(button(t,a,false), LinearLayout.LayoutParams(0,dp(76),1f).apply { setMargins(3,5,3,5) })
        }
        content.addView(quick)
        content.addView(cardView("📢 ANNOUNCEMENT",
            "Room ID & Password will be shared before the match. Stay tuned.",
            "VIEW LIVE & UPDATES") { showLive() },
            LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(10); bottomMargin=dp(10) })
        content.addView(cardView("🏆 HALL OF FAME",
            "Latest winner: Hassan FF\nKills: 12  •  Points: 120",
            "VIEW LEADERBOARD") { showLeaderboard() })
    }

    private fun showTournaments() {
        base("Tournaments", "Upcoming Free Fire events")
        content.addView(cardView("SOLO BATTLE #001",
            "50 Slots • Rs.100 Entry\n32 booked • Minimum 25\n12 Sep 2026 • 8:00 PM PKT",
            "VIEW & BOOK") { showTournamentDetails() })
        content.addView(cardView("DUO BATTLE #002",
            "100 Slots • Rs.200 Entry\n12 booked • Prize Rs.10,000\n15 Sep 2026 • 8:00 PM PKT",
            "VIEW DETAILS") { showTournamentDetails() },
            LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(12) })
        content.addView(cardView("SOLO BATTLE #003",
            "Registration opening soon\n50 Slots • Entry Rs.100",
            "COMING SOON") { Toast.makeText(this,"Registration is not open yet.",Toast.LENGTH_SHORT).show() },
            LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(12) })
    }

    private fun showTournamentDetails() {
        base("Tournament Details", "SOLO BATTLE #001", true)
        content.addView(cardView("⚔ SOLO BATTLE #001",
            "Upcoming\n\n📅 12 September 2026\n⏰ 8:00 PM PKT\n🎮 Mode: Solo\n🗺 Map: Bermuda\n💰 Entry: Rs.100\n🏆 Prize: Rs.5,000\n👥 50 total • Minimum 25"))
        content.addView(tv("Slots (50)", 18f, white, true).apply { setPadding(4,dp(18),4,dp(8)) })

        val legend = tv("🟢 Available     🔴 Booked     🟡 Your Slot", 12f, muted)
        content.addView(legend)

        val grid = GridLayout(this).apply {
            columnCount = 5
            rowCount = 10
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        for (i in 1..50) {
            val b = Button(this).apply {
                text = "$i"
                textSize = 12f
                setTextColor(Color.WHITE)
                val isBooked = booked.contains(i)
                val isSelected = selectedSlot == i
                setBackgroundColor(when {
                    isSelected -> gold
                    isBooked -> red
                    else -> green
                })
                if (isBooked && !isSelected) isEnabled = false
                setOnClickListener {
                    selectedSlot = i
                    showTournamentDetails()
                }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0; height = dp(48)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(3,3,3,3)
            }
            grid.addView(b, lp)
        }
        content.addView(grid)
        content.addView(button("BOOK SLOT #$selectedSlot", { showRegistration() }),
            LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(10) })
    }

    private fun showRegistration() {
        base("Registration", "Step 1 of 3 • Player Details", true)
        val name = EditText(this).apply { hint="Player Name"; setTextColor(white); setHintTextColor(muted) }
        val uid = EditText(this).apply { hint="Free Fire UID"; setTextColor(white); setHintTextColor(muted) }
        val phone = EditText(this).apply { hint="WhatsApp / Phone"; setTextColor(white); setHintTextColor(muted) }
        val email = EditText(this).apply { hint="Email Address"; setTextColor(white); setHintTextColor(muted) }
        listOf(name,uid,phone,email).forEach {
            it.setPadding(dp(14),0,dp(14),0)
            content.addView(it, LinearLayout.LayoutParams(-1,dp(58)).apply{bottomMargin=dp(8)})
        }
        content.addView(tv("Selected Slot: #$selectedSlot",16f,gold,true))
        content.addView(button("NEXT — PAYMENT") { showPayment(name.text.toString(), uid.text.toString()) },
            LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(10)})
    }

    private fun showPayment(name: String, uid: String) {
        base("Payment", "Step 2 of 3 • JazzCash", true)
        content.addView(cardView("💳 JAZZCASH",
            "Send Rs.100 to:\n0322 4330245\n\nPayment is manually verified by Admin."))
        val tx = EditText(this).apply { hint="Transaction ID"; setTextColor(white); setHintTextColor(muted) }
        content.addView(tx, LinearLayout.LayoutParams(-1,dp(58)).apply{topMargin=dp(12)})
        content.addView(cardView("📸 Payment Screenshot",
            "Demo: screenshot upload area\n(Connect a real backend/storage for production.)"))
        content.addView(button("SUBMIT REGISTRATION") {
            booked.add(selectedSlot)
            showSuccess(name.ifBlank{"Player"}, uid.ifBlank{"—"}, tx.text.toString())
        }, LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(12)})
    }

    private fun showSuccess(name:String, uid:String, tx:String) {
        base("Registration Successful", "Your booking has been submitted", true)
        content.gravity=Gravity.CENTER_HORIZONTAL
        content.addView(tv("✓",72f,green,true))
        content.addView(tv("Registration Successful!",24f,white,true))
        content.addView(tv("Your slot has been booked.",15f,muted))
        content.addView(cardView("SOLO BATTLE #001",
            "Player: $name\nUID: $uid\nSlot: #$selectedSlot\nTransaction: ${tx.ifBlank{"Pending"}}\nPayment Status: ⏳ Pending Verification"),
            LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(18)})
        content.addView(button("GO TO MY SLOTS",{showMySlots()}),LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(14)})
    }

    private fun showMySlots() {
        base("My Slots", "Your tournament activity")
        content.addView(cardView("SOLO BATTLE #001",
            "Slot #$selectedSlot\n12 Sep 2026 • 8:00 PM PKT\nPayment: ⏳ Pending Verification\nRoom Code: Will appear after Admin sends it.",
            "VIEW DETAILS") { showTournamentDetails() })
        content.addView(cardView("📢 STATUS",
            "You will be notified when payment is verified and room details are released."))
    }

    private fun showLive() {
        base("Live / Announcements", "Stay updated")
        content.addView(cardView("🔴 BOYYAH ARENA LIVE",
            "Watch the tournament stream on YouTube.",
            "WATCH ON YOUTUBE") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@emjay_ff-qp7ct")))
            })
        content.addView(cardView("Upcoming",
            "• Room ID will be shared 10 minutes before match.\n• Join on time.\n• Follow all rules.\n• Contact admin for help."))
    }

    private fun showLeaderboard() {
        base("Leaderboard", "Current rankings")
        content.addView(cardView("🏆 HALL OF FAME",
            "1  👑 Hassan FF     12 kills   120 pts\n2  🥈 Zain 777       10 kills   100 pts\n3  🥉 Ali 444          9 kills    90 pts\n4     Mazhar FF        8 kills    80 pts\n5     Asad FF          7 kills    70 pts"))
        content.addView(cardView("Latest Winner",
            "Hassan FF\n12 Kills • 120 Points\nSOLO BATTLE #001"))
    }

    private fun showProfile() {
        base("Profile", "Player account")
        content.addView(cardView("👤 Player Profile",
            "Mazhar FF\nFree Fire UID: 123456789\nPhone: 03001234567"))
        content.addView(button("MY SLOTS") { showMySlots() })
        content.addView(button("RULES") { showRules() })
        content.addView(button("ADMIN PANEL (DEMO)") { showAdmin() })
    }

    private fun showRules() {
        base("Rules", "Boyyah Arena tournament rules", true)
        content.addView(cardView("📜 Tournament Rules",
            "1. One player can book one slot per tournament.\n\n2. Genuine payment proof is required.\n\n3. Minimum 25 verified players are required to start.\n\n4. Room ID and Password are provided by Admin.\n\n5. Admin decision is final.\n\n6. Winner is announced by Admin."))
    }

    private fun showAdmin() {
        base("Admin Panel", "Demo control center", true)
        val actions = listOf(
            "➕ Create Tournament" to "Create/edit tournaments, date, fee and prize.",
            "👥 Manage Players" to "View UIDs, slots and player status.",
            "✓ Verify Payments" to "Approve/reject manual JazzCash payments.",
            "📢 Send Announcement" to "Publish tournament announcements.",
            "🔑 Set Room Code" to "Send Room ID/password once.",
            "🏆 Results & Winners" to "Announce winner and Hall of Fame."
        )
        actions.forEach { (a,b) ->
            content.addView(cardView(a,b,"OPEN") {
                Toast.makeText(this,"Demo action: $a",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})
        }
    }
}
