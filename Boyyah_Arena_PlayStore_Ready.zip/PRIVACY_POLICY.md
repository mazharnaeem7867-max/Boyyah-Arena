# Boyyah Arena Privacy Policy

Boyyah Arena is a Free Fire tournament companion app.

## Information
The production version may collect information needed for tournament registration, such as player name, Free Fire UID, phone number, email, payment reference, and tournament booking details.

## Payments
Tournament entry payments are handled through the payment method shown by the tournament organizer. The app does not store card PINs, passwords, or banking credentials.

## Sharing
Information may be shared with the tournament administrator only as needed to operate tournaments, verify payments, assign slots, announce winners, and provide room information.

## Contact
Replace this section with the official Boyyah Arena support email before publishing.

This document is a template and must be reviewed and completed with the actual production data practices before Play Store submission.
