# Play Store checklist

1. Create/verify Google Play developer account.
2. Complete developer identity verification.
3. Replace the privacy-policy template with the real policy and a public URL.
4. Connect a production backend.
5. Configure real authentication, tournament database, payment verification and admin access.
6. Generate a signed Android App Bundle (.aab).
7. Upload the AAB to Play Console.
8. Complete store listing, app content, data safety and other declarations.
9. Run the required closed test if using a new personal developer account.
10. Apply for production access and publish after approval.
