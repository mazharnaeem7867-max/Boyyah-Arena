# Boyyah Arena — Android App

This is the Android Studio project for the Boyyah Arena Free Fire tournament app.

## What is included
- Premium black/gold Boyyah Arena UI
- Home, tournaments, tournament details
- 50-slot tournament grid
- Registration and JazzCash reference screen
- Booking success
- My Slots
- Live / announcements
- Leaderboard / Hall of Fame
- Profile
- Rules
- Admin demo screen
- Launcher icon
- Privacy-policy template
- Package name: `com.boyyaharena.app`
- Version: 1.1 (versionCode 2)

## Important
This project is Play-Store-ready as a project, but it is still a frontend/demo build. A real public tournament service needs a backend/database, secure authentication, admin verification, notifications, and real payment workflow.

## Money
You do NOT need to pay me to create or prepare this project.

Google currently requires a one-time US$25 developer registration fee for full Google Play distribution. There is no monthly Play Store fee for simply keeping an app published, although other Google services or monetized transactions can have separate costs.

## If you have no money right now
Use the app as an Android APK for testing/sharing first. When you can afford the Google registration fee, create your Play developer account and publish the signed AAB.

For new personal Play developer accounts, Google currently also requires a closed test with at least 12 opted-in testers continuously for 14 days before production access.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Generate Signed Bundle / APK > Android App Bundle

Do not publish with the demo backend/UI as a real-money tournament system until the production backend and privacy policy are completed.
